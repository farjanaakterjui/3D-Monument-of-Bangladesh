#include<GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <stdio.h>
#include <windows.h>
#include<math.h>
#include<bits/stdc++.h>
#include<string>
#include "BmpLoader.h"
#define PI 3.1415927

using namespace std;

double Txval=0,Tyval=0,Tzval=0,meghX=0,clo=1,clo1=1 ;
double eyeX=0.0, eyeY=2.5, eyeZ=20, refX = 0,refY=2.5,refZ=0,f=0,f1=0,f2=0,f3=0,n1=0,n2=0;
double windowHeight=900, windowWidth=900;
const int width = 1400;
const int height = 900;
GLfloat alpha = 0.0, theta = 0.0, axis_x=0.0, axis_y=0.0;
GLboolean bRotate = false, uRotate = false,s1 = true,s2 = true,s3 = true;
bool flag=false,a0=true,d0=true,s0=true;
GLfloat ya = 50,xa = 10;
int yFlag = 1, xFlag = 1,AniFlag=1;
unsigned int id;
vector<int> ID;


static GLfloat v_box[8][3] =
{
    {-2.0, 0.0, -2.0},
    {2.0, 0.0, -2.0},
    {-2.0, 0.0, 2.0},
    {2.0, 0.0, 2.0},

    {-2.0, 2.0, -2.0},
    {2.0, 2.0, -2.0},
    {-2.0, 2.0, 2.0},
    {2.0, 2.0, 2.0}
};


static GLubyte quadIndices[6][4] =
{
    {0,2,3,1},
    {0,2,6,4},
    {2,3,7,6},
    {1,3,7,5},
    {1,5,4,0},
    {6,7,5,4}
};

static GLfloat triangle[6][3] =
{
    {0.0, 0.0, 0.0},
    {1.0, 0.0, 0.0},
    {0.0, 1.0, 0.0},

    // {0.0, 0.0, 1.0},
    {1.0, 0.0, 1.0},
    //{0.0, 1.0, 1.0}

};


static GLubyte triIndices[4][3] =
{
    {0,1,2},
    {0,3,2},
    {0,3,1},
    {2,3,1}
};

static GLfloat tri[6][3] =
{
    {0.0, 0.0, 0.0},
    {1.0, 0.0, 0.0},
    {0.0, 1.0, 0.0},

    {0.0, 0.0, 1.0},
    {1.0, 0.0, 1.0},
    {0.0, 1.0, 1.0}

};


static GLubyte Indices[2][3] =
{
    {0,1,2},
    {3,4,5}
};
static GLubyte quad[3][4] =
{
    {0, 1, 4, 3},
    {0, 3, 5, 2},
    {1, 4, 5, 2}
};
GLfloat no_light[] = { 0.0, 0.0, 0.0, 1.0 };
GLfloat light_ambient[]  = {0.3, 0.3, 0.3, 1.0};
GLfloat light_diffuse[]  = { 1.0, 1.0, 1.0, 1.0 };
GLfloat light_specular[] = { 1.0, 1.0, 1.0, 1.0 };
GLfloat mat_emission[] = {0.3, 0.2, 0.2, 0.0};

static void getNormal3p
(GLfloat x1, GLfloat y1,GLfloat z1, GLfloat x2, GLfloat y2,GLfloat z2, GLfloat x3, GLfloat y3,GLfloat z3)
{
    GLfloat Ux, Uy, Uz, Vx, Vy, Vz, Nx, Ny, Nz;

    Ux = x2-x1;
    Uy = y2-y1;
    Uz = z2-z1;

    Vx = x3-x1;
    Vy = y3-y1;
    Vz = z3-z1;

    Nx = Uy*Vz - Uz*Vy;
    Ny = Uz*Vx - Ux*Vz;
    Nz = Ux*Vy - Uy*Vx;

    glNormal3f(Nx,Ny,Nz);
}

void drawBox(double x=1,double y=1,double z=1 )
{
    GLfloat no_mat[] = { 0.0, 0.0, 0.0, 1.0 };
    GLfloat mat_ambient[] = { 0.5*x, 0.5*y, 0.5*z, 1.0 };
    GLfloat mat_diffuse[] = { x, y, z, 1.0 };
    GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat mat_shininess[] = {60};
    GLfloat mat_emission[] = {0.3*x, 0.2*y, 0.2*z, 1.0};

    glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
    glMaterialfv( GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv( GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv( GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv( GL_FRONT, GL_SHININESS, mat_shininess);

    glBegin(GL_QUADS);
    for (GLint i = 0; i <6; i++)
    {
        //glColor3f(colors[4][0],colors[4][1],colors[4][2]);
        getNormal3p(v_box[quadIndices[i][0]][0], v_box[quadIndices[i][0]][1], v_box[quadIndices[i][0]][2],
                    v_box[quadIndices[i][1]][0], v_box[quadIndices[i][1]][1], v_box[quadIndices[i][1]][2],
                    v_box[quadIndices[i][2]][0], v_box[quadIndices[i][2]][1], v_box[quadIndices[i][2]][2]);

        glVertex3fv(&v_box[quadIndices[i][0]][0]);
        glTexCoord2f(1,1);
        glVertex3fv(&v_box[quadIndices[i][1]][0]);
        glTexCoord2f(1,0);
        glVertex3fv(&v_box[quadIndices[i][2]][0]);
        glTexCoord2f(0,0);
        glVertex3fv(&v_box[quadIndices[i][3]][0]);
        glTexCoord2f(0,1);
    }
    glEnd();
    //glutSolidSphere (3.0, 20, 16);

}


void drawtriangle(double x=1,double y=1,double z=1)
{
    GLfloat no_mat[] = { 0.0, 0.0, 0.0, 1.0 };
    GLfloat mat_ambient[] = { 0.5*x, 0.5*y, 0.5*z, 1.0 };
    GLfloat mat_diffuse[] = { x, y, z, 1.0 };
    GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat mat_shininess[] = {60};
    GLfloat mat_emission[] = {0.3*x, 0.2*y, 0.2*z, 1.0};

    glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
    glMaterialfv( GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv( GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv( GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv( GL_FRONT, GL_SHININESS, mat_shininess);


    glBegin(GL_TRIANGLES);
    for (GLint i = 0; i <4; i++)
    {
        // glColor3f(1,0,0);
        getNormal3p(triangle[triIndices[i][0]][0], triangle[triIndices[i][0]][1], triangle[triIndices[i][0]][2],
                    triangle[triIndices[i][1]][0], triangle[triIndices[i][1]][1], triangle[triIndices[i][1]][2],
                    triangle[triIndices[i][2]][0], triangle[triIndices[i][2]][1], triangle[triIndices[i][2]][2]);

        glVertex3fv(&triangle[triIndices[i][0]][0]);
        glTexCoord2f(0,0);
        glVertex3fv(&triangle[triIndices[i][1]][0]);
        glTexCoord2f(1,0);
        glVertex3fv(&triangle[triIndices[i][2]][0]);
        glTexCoord2f(0,1);
    }
    glEnd();

}
void drawtri(double x=1,double y=1,double z=1)
{
    GLfloat no_mat[] = { 0.0, 0.0, 0.0, 1.0 };
    GLfloat mat_ambient[] = { 0.5*x, 0.5*y, 0.5*z, 1.0 };
    GLfloat mat_diffuse[] = { x, y, z, 1.0 };
    GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat mat_shininess[] = {60};
    GLfloat mat_emission[] = {0.3*x, 0.2*y, 0.2*z, 1.0};

    glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
    glMaterialfv( GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv( GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv( GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv( GL_FRONT, GL_SHININESS, mat_shininess);


    glBegin(GL_TRIANGLES);
    for (GLint i = 0; i <2; i++)
    {
        // glColor3f(1,0,0);
        getNormal3p(tri[Indices[i][0]][0], tri[Indices[i][0]][1], tri[Indices[i][0]][2],
                    tri[Indices[i][1]][0], tri[Indices[i][1]][1], tri[Indices[i][1]][2],
                    tri[Indices[i][2]][0], tri[Indices[i][2]][1], tri[Indices[i][2]][2]);

        glVertex3fv(&tri[Indices[i][0]][0]);
        glTexCoord2f(0,0);
        glVertex3fv(&tri[Indices[i][1]][0]);
        glTexCoord2f(1,0);
        glVertex3fv(&tri[Indices[i][2]][0]);
        glTexCoord2f(0,1);
    }
    glEnd();

    glBegin(GL_QUADS);
    for (GLint i = 0; i <3; i++)
    {
        //glColor3f(colors[4][0],colors[4][1],colors[4][2]);
        getNormal3p(tri[quad[i][0]][0], tri[quad[i][0]][1], tri[quad[i][0]][2],
                    tri[quad[i][1]][0], tri[quad[i][1]][1], tri[quad[i][1]][2],
                    tri[quad[i][2]][0], tri[quad[i][2]][1], tri[quad[i][2]][2]);
        glVertex3fv(&tri[quad[i][0]][0]);
        glTexCoord2f(1,1);
        glVertex3fv(&tri[quad[i][1]][0]);
        glTexCoord2f(1,0);
        glVertex3fv(&tri[quad[i][2]][0]);
        glTexCoord2f(0,0);
        glVertex3fv(&tri[quad[i][3]][0]);
        glTexCoord2f(0,1);
    }
    glEnd();


}
int anglex= 0, angley = 0, anglez = 0;          //rotation angles
int window;
int wired=0;
int shcpt=1;
int animat = 0;
const int L=14;
const int dgre=3;
int ncpt=L+1;
int clikd=0;
const int nt = 40;				//number of slices along x-direction
const int ntheta = 20;


GLfloat ctrlpoints[L+1][3] =
{
    /*  { 0.0, 0.0, 0.0}, { -0.3, 0.5, 0.0},
      { 0.1, 1.7, 0.0},{ 0.5, 1.5, 0.0},
      {1.0, 1.5, 0.0}, {1.4, 1.4, 0.0},
      {1.8, 0.4, 0.0},*/
    {2.2, 0.4, 0.0},{ 1.6, -0.0999999,0.0},
    {2.6, 1.5, 0.0}, {3.0, 1.4, 0.0},
    {3.4, 1.4, 0.0},{3.8, 1.4, 0.0},
    {4.2, 1.0, 0.0},{4.6, 1.0, 0.0},
    {5.0, 1.0, 0.0},{5.4, 1.0, 0.0},
    {5.8, 0.5, 0.0},{6.2, 0.5, 0.0},
    {6.6, 0.5, 0.0},{7.2, 0.2, 0.0},
    {7.525, -0.0250002,0}
    /* {6.8, 0.52, 0.0}*/
};


double ex=0, ey=0, ez=15, lx=0,ly=0,lz=0, hx=0,hy=1,hz=0;

float wcsClkDn[3],wcsClkUp[3];
///////////////////////////////
class point1
{
public:
    point1()
    {
        x=0;
        y=0;
    }
    int x;
    int y;
} clkpt[2];
//int flag=0;
GLint viewport[4]; //var to hold the viewport info
GLdouble modelview[16]; //var to hold the modelview info
GLdouble projection[16]; //var to hold the projection matrix info

//////////////////////////
void scsToWcs(float sx,float sy, float wcsv[3] );
void processMouse(int button, int state, int x, int y);
void matColor(float kdr, float kdg, float kdb,  float shiny, int frnt_Back=0, float ambFactor=1.0, float specFactor=1.0);
///////////////////////////

void scsToWcs(float sx,float sy, float wcsv[3] )
{

    GLfloat winX, winY, winZ; //variables to hold screen x,y,z coordinates
    GLdouble worldX, worldY, worldZ; //variables to hold world x,y,z coordinates

    //glGetDoublev( GL_MODELVIEW_MATRIX, modelview ); //get the modelview info
    glGetDoublev( GL_PROJECTION_MATRIX, projection ); //get the projection matrix info
    glGetIntegerv( GL_VIEWPORT, viewport ); //get the viewport info

    winX = sx;
    winY = (float)viewport[3] - (float)sy;
    winZ = 0;

    //get the world coordinates from the screen coordinates
    gluUnProject( winX, winY, winZ, modelview, projection, viewport, &worldX, &worldY, &worldZ);
    wcsv[0]=worldX;
    wcsv[1]=worldY;
    wcsv[2]=worldZ;


}
void processMouse(int button, int state, int x, int y)
{
    if(button==GLUT_LEFT_BUTTON && state==GLUT_DOWN)
    {
        if(flag!=1)
        {
            flag=1;
            clkpt[0].x=x;
            clkpt[0].y=y;
        }


        scsToWcs(clkpt[0].x,clkpt[0].y,wcsClkDn);
        cout<<"\nD: "<<x<<" "<<y<<" wcs: "<<wcsClkDn[0]<<" "<<wcsClkDn[1];
    }
    else if(button==GLUT_LEFT_BUTTON && state==GLUT_UP)
    {
        if (flag==1)
        {
            clkpt[1].x=x;
            clkpt[1].y=y;
            flag=0;
        }
        float wcs[3];
        scsToWcs(clkpt[1].x,clkpt[1].y,wcsClkUp);
        cout<<"\nU: "<<x<<" "<<y<<" wcs: "<<wcsClkUp[0]<<" "<<wcsClkUp[1];

        clikd=!clikd;
    }
}

//control points
long long nCr(int n, int r)
{
    if(r > n / 2) r = n - r; // because C(n, r) == C(n, n - r)
    long long ans = 1;
    int i;

    for(i = 1; i <= r; i++)
    {
        ans *= n - r + i;
        ans /= i;
    }

    return ans;
}

//polynomial interpretation for N points
void BezierCurve ( double t,  float xy[2])
{
    double y=0;
    double x=0;
    t=t>1.0?1.0:t;
    for(int i=0; i<=L; i++)
    {
        int ncr=nCr(L,i);
        double oneMinusTpow=pow(1-t,double(L-i));
        double tPow=pow(t,double(i));
        double coef=oneMinusTpow*tPow*ncr;
        x+=coef*ctrlpoints[i][0];
        y+=coef*ctrlpoints[i][1];

    }
    xy[0] = float(x);
    xy[1] = float(y);

    //return y;
}

///////////////////////
void setNormal(GLfloat x1, GLfloat y1,GLfloat z1, GLfloat x2, GLfloat y2,GLfloat z2, GLfloat x3, GLfloat y3,GLfloat z3)
{
    GLfloat Ux, Uy, Uz, Vx, Vy, Vz, Nx, Ny, Nz;

    Ux = x2-x1;
    Uy = y2-y1;
    Uz = z2-z1;

    Vx = x3-x1;
    Vy = y3-y1;
    Vz = z3-z1;

    Nx = Uy*Vz - Uz*Vy;
    Ny = Uz*Vx - Ux*Vz;
    Nz = Ux*Vy - Uy*Vx;

    glNormal3f(-Nx,-Ny,-Nz);
}

void bottleBezier()
{
    int i, j;
    float x, y, z, r;				//current coordinates
    float x1, y1, z1, r1;			//next coordinates
    float theta;

    const float startx = 0, endx = ctrlpoints[L][0];
    //number of angular slices
    const float dx = (endx - startx) / nt;	//x step size
    const float dtheta = 2*PI / ntheta;		//angular step size

    float t=0;
    float dt=1.0/nt;
    float xy[2];
    BezierCurve( t,  xy);
    x = xy[0];
    r = xy[1];
    //rotate about z-axis
    float p1x,p1y,p1z,p2x,p2y,p2z;
    for ( i = 0; i < nt; ++i )  			//step through x
    {
        theta = 0;
        t+=dt;
        BezierCurve( t,  xy);
        x1 = xy[0];
        r1 = xy[1];

        //draw the surface composed of quadrilaterals by sweeping theta
        glBegin( GL_QUAD_STRIP );
        for ( j = 0; j <= ntheta; ++j )
        {
            theta += dtheta;
            double cosa = cos( theta );
            double sina = sin ( theta );
            y = r * cosa;
            y1 = r1 * cosa;	//current and next y
            z = r * sina;
            z1 = r1 * sina;	//current and next z

            //edge from point at x to point at next x
            glVertex3f (x, y, z);

            if(j>0)
            {
                setNormal(p1x,p1y,p1z,p2x,p2y,p2z,x, y, z);
            }
            else
            {
                p1x=x;
                p1y=y;
                p1z=z;
                p2x=x1;
                p2y=y1;
                p2z=z1;

            }
            glVertex3f (x1, y1, z1);

            //forms quad with next pair of points with incremented theta value
        }
        glEnd();
        x = x1;
        r = r1;
    } //for i

}


static void resizeView(int width, int height)
{
    //glViewport(0, 0, width, width/rat);
    const float ar = (float) width / (float) height;

    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-ar, ar, -2.0, 2.0, 2.0, 100.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity() ;
}


void light()//SUNlight normal light & moonlight spotlight
{
//
    GLfloat light_position[] = {-20,28,-30,1 };
    glEnable( GL_LIGHT0);

    if( s1&&a0)
        glLightfv( GL_LIGHT0, GL_AMBIENT, light_ambient);
    else
        glLightfv( GL_LIGHT0, GL_AMBIENT, no_light);

    if( s1&&d0)
        glLightfv( GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    else
        glLightfv( GL_LIGHT0, GL_DIFFUSE, no_light);
    if(s1&& s0)
        glLightfv( GL_LIGHT0, GL_SPECULAR, light_specular);
    else
        glLightfv( GL_LIGHT0, GL_SPECULAR, no_light);

    glLightfv( GL_LIGHT0, GL_POSITION, light_position);
    glLightfv(GL_FRONT, GL_EMISSION, mat_emission);
    if(n1==1)
    {
        GLfloat spot_direction[] = { 0.0, -1.0, 0.0 };
        glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, spot_direction);
        glLightf( GL_LIGHT0, GL_SPOT_CUTOFF, 120.0);
    }

}
void light1()//MIDDLElight
{
    GLfloat light_position[] = {0,3,3,1 };

    glEnable( GL_LIGHT1);
    if( s2&&a0)
        glLightfv( GL_LIGHT1, GL_AMBIENT, light_ambient);
    else
        glLightfv( GL_LIGHT1, GL_AMBIENT, no_light);

    if( s2&&d0)
        glLightfv( GL_LIGHT1, GL_DIFFUSE, light_diffuse);
    else
        glLightfv( GL_LIGHT1, GL_DIFFUSE, no_light);
    if(s2&& s0)
        glLightfv( GL_LIGHT1, GL_SPECULAR, light_specular);
    else
        glLightfv( GL_LIGHT1, GL_SPECULAR, no_light);


    glLightfv( GL_LIGHT1, GL_POSITION, light_position);
    glLightfv(GL_FRONT, GL_EMISSION, mat_emission);

}


void Drawflag()
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[9]);
    GLfloat x[4],y1[4],y2[4],y3[4],y4[4];
    GLdouble xt[200],y1t[200],y2t[200],y3t[200],y4t[200],t;
    int i,c;
    float j;

    x[0] = 100;
    x[1] = 200;
    x[2] = 200;
    x[3] = 300-xa;
    y1[0] = 450;
    y1[1] = 450+ya;
    y1[2] = 450-ya;
    y1[3] = 450;
    y2[0] = 300;
    y2[1] = 300+ya;
    y2[2] = 300-ya;
    y2[3] = 300;

    for(i=0,t=0,c=0; t<1; i++,t=t+0.01)
    {
        xt[i] = pow(1-t,3)*x[0]+3*t*pow(1-t,2)*x[1]+3*pow(t,2)*(1-t)*x[2]+pow(t,3)*x[3];
        y1t[i] = pow(1-t,3)*y1[0]+3*t*pow(1-t,2)*y1[1]+3*pow(t,2)*(1-t)*y1[2]+pow(t,3)*y1[3];
        y2t[i] = pow(1-t,3)*y2[0]+3*t*pow(1-t,2)*y2[1]+3*pow(t,2)*(1-t)*y2[2]+pow(t,3)*y2[3];
        c++;
    }


    glBegin(GL_QUAD_STRIP);



    for(i=0,j=0; i<c; i++,j+=1.0/c)
    {
        glVertex2d(xt[i],y1t[i]);
        glTexCoord2f(1,j);
        glVertex2d(xt[i],y2t[i]);
        glTexCoord2f(0,j);

    }


    glEnd();


    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void floor()
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[0]);

    glTranslatef(0,0,Tzval);
    glScalef(30,0.25,30);
    drawBox();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void cylinder()
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[3]);
    GLUquadricObj *quadratic;
    quadratic = gluNewQuadric();
    gluQuadricTexture(quadratic,1);
    glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
    gluCylinder(quadratic,0.15f,0.15f,1.5f,32,32);
    gluDeleteQuadric(quadratic);
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}
void sphere(double x=1,double y=1,double z=1)
{
    glPushMatrix();
    GLfloat no_mat[] = { 0.0, 0.0, 0.0, 1.0 };
    GLfloat mat_ambient[] = { 0.5*x, 0.5*y, 0.5*z, 1.0 };
    GLfloat mat_diffuse[] = { x, y, z, 1.0 };
    GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat mat_shininess[] = {60};
    GLfloat mat_emission[] = {0.3*x, 0.2*y, 0.2*z, 1.0};
    GLUquadric *qobj = gluNewQuadric();
    gluQuadricTexture(qobj, GL_TRUE);
    glRotatef(90.0f, 1.0f, 1.0f, 0.0f);
    gluSphere(qobj, 2, 20, 16);
    gluDeleteQuadric(qobj);
    glPopMatrix();

}
void base(float a,float b,float c)//base triangle
{

    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[1]);

    glTranslatef(0,0,Tzval);

    glRotatef(c, 0.0, 1.0, 0.0);
    glScalef(a,b,0.2);

    //ellipse();
    drawtriangle();
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);


}

void base1()//1st base middle triangle and extend quad
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[1]);

    //mid();
    glRotatef(45,0,0,1);
    glScalef(0.5,1,0.05);
    drawBox();
    glPopMatrix();
    glPushMatrix();

    glScalef(0.7,0.125,0.15);
    glTranslatef(-1,4.5,0.05);
    drawBox();
    // glRotatef(180,1,0,0);

    //mid();
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void base2()//1st base complete
{
    glPushMatrix();
    base(1,8,225);
    base(1,8,315);
    //glTranslatef(0.1,3,0.25);
    //glScalef(0.2,1.25,1);
    //base1();
    glPopMatrix();
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[1]);
    glTranslatef(0,3,0);
    glScalef(0.60,0.5,0.60);
    glRotatef(90,1,0,0);
    glRotatef(50,0,0,1);
    drawtri();
    glPopMatrix();

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[1]);
    glBegin(GL_TRIANGLE_FAN);
    glVertex3f(0.0,0.0,0.0);
    glTexCoord2f(0,0);
    glVertex3f(-0.35,2.5,0.35);
    glTexCoord2f(1,0);
    glVertex3f(0.35,2.5,0.35);
    glTexCoord2f(0,1);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[1]);
    glBegin(GL_TRIANGLE_FAN);
    glVertex3f(0.0,5,0.0);
    glTexCoord2f(0,0);
    glVertex3f(-0.35,3,0.35);
    glTexCoord2f(1,0);
    glVertex3f(0.35,3,0.35);
    glTexCoord2f(0,1);
    glEnd();
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}
void Flag()//flag with stand
{
    //glEnable(GL_TEXTURE_2D);
        glPushMatrix();
    //glBindTexture(GL_TEXTURE_2D,ID[9]);

    //mid();
    glScalef(0.0125,0.0125,0.0125);
    glTranslatef(-180,150,80);
    //glScalef(0.5,1,0.000000001);
    //drawBox();
    Drawflag();
    glPopMatrix();
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[1]);

    //mid();
    glTranslatef(-1,0,1);
    glScalef(0.025,4,0.001);
    drawBox(0.149, 0.094, 0.109);
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}
void monument(int x)//bases //parameter for rotate flag along y axis
{
    glPushMatrix();
    //glRotatef(45,0,1,0);

    glScalef(0.095,1,0.095);
    glTranslatef(0,-0.5,-45);
    floor();
    glPopMatrix();
    glPushMatrix();

    glPushMatrix();
    // glTranslatef(-0.1,3,-0.25);
    base2();
    // glTranslatef(0,0,-1);
    for (float i=7,j=2,c=-1,p=0; p<6; p++,i-=1,j+=1,c-=0.25)
    {
        glTranslatef(0,0,c);
        base(j,i,225);
        base(j,i,315);
    }
    glPopMatrix();

glPushMatrix();
glRotatef(x,0,1,0);
if(x==180)glTranslatef(0,0,-2);
Flag();
glPopMatrix();

    glPushMatrix();//light
    glScalef(0.025,0.25,0.025);
    glTranslatef(0,-1.25,15);
    drawBox(1,1,1);
    glPopMatrix();

    glPushMatrix();
    // glColor3f(1,1,1);

    glScalef(0.125,0.125,0.125);
    glTranslatef(0,3,3);
    sphere();
    glPopMatrix();


}


void tree1()
{
    glPushMatrix();
    glScalef(0.25,0.5,0.25);
    cylinder();
    glPopMatrix();

    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[2]);

    glScalef(0.5,1,0.5);
    glTranslatef(0,1.75,0);
    sphere();
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

}
void cloud()
{

    glEnable(GL_TEXTURE_2D);
    glScalef(0.5,1,0.5);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[5]);


    glTranslatef(0,4,0);
    glScalef(1.15,1.15,1.15);
    sphere();
    glPopMatrix();
    glPushMatrix();
    //glScalef(1.5,1.5,1.5);
    glTranslatef(-1,1.5,1);
    sphere();
    glPopMatrix();
    glPushMatrix();
    //glScalef(1.5,1.5,1.5);
    glTranslatef(2,1.25,1.5);
    sphere();
    glPopMatrix();
    glPushMatrix();
    // glScalef(0.75,1,0.75);
    glTranslatef(3.75,2.5,0);
    sphere();
    glPopMatrix();
    glPushMatrix();
    // glScalef(0.75,1,0.75);
    glTranslatef(-3.75,2.5,0);
    sphere();
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}
void grass()//quad grass carpet
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[6]);
    //glTranslatef(0,0,Tzval);
    glScalef(3,0.25,2.5);
    drawBox();
    glPopMatrix();

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[0]);
    glScalef(3.5,0.5,0.25);
    glTranslatef(0,0,20);
    drawBox();
    glPopMatrix();

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[0]);
    glScalef(3.5,0.5,0.25);
    glTranslatef(0,0,-20);
    drawBox();
    glPopMatrix();

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[0]);
    glScalef(0.25,0.5,2.25);
    glTranslatef(26,0,0);
    drawBox();
    glPopMatrix();

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[0]);
    glScalef(0.25,0.5,2.25);
    glTranslatef(-26,0,0);
    drawBox();
    glPopMatrix();

    glDisable(GL_TEXTURE_2D);
}

void grass2()//triangle grass carpet
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[6]);
    //glTranslatef(10,2,0);
    glScalef(5,1,5);
    glRotatef(90,1,0,0);
    glRotatef(-45,0,0,1);
    //glRotatef(45,0,1,0);
    //tri_base_grass();
    drawtri(1,1,0);
    glPopMatrix();
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[0]);
    glTranslatef(-1,-1,0);
    glScalef(7.5,1,7.5);
    glRotatef(90,1,0,0);
    glRotatef(-45,0,0,1);
    //glRotatef(45,0,1,0);
    //tri_base_grass();
    drawtri(1,1,0);
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

}
void trees(float x)
{
    //glRotatef(90,1,0,0);
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[0]);
    glScalef(x,0.25,0.5);
    drawBox();
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
    glPushMatrix();
    glTranslatef(-(2*x-2.25),1,0);
    for(int i=1; i<=int(4*x/2.25); i++)
    {


        tree1();
        glTranslatef(2.25,0,0);

    }
    glPopMatrix();
}
void tri_base_grass()
{
    glPushMatrix();
    //glRotatef(90,1,0,0);
    grass2();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0.5,0.25,0);
    glScalef(0.5,0.5,0.5);

    tree1();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(1.5,0.25,0.75);
    glScalef(0.5,0.5,0.5);

    tree1();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(2.5,0.25,1.5);
    glScalef(0.5,0.5,0.5);

    tree1();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(3.5,0.25,2.25);
    glScalef(0.5,0.5,0.5);

    tree1();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(1.5,0.25,-0.75);
    glScalef(0.5,0.5,0.5);

    tree1();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(2.5,0.25,-1.5);
    glScalef(0.5,0.5,0.5);

    tree1();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(3.5,0.25,-2.25);
    glScalef(0.5,0.5,0.5);

    tree1();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(3.5,0.25,-0.5);
    glScalef(0.5,0.5,0.5);

    tree1();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(3.5,0.25,1);
    glScalef(0.5,0.5,0.5);

    tree1();
    glPopMatrix();
}

void movecloud(float a)

{
    // float meghX=meghX+a;
    if (clo == 1)
    {
        meghX +=.005;
    }
    if (meghX+a>35)
    {
        meghX = -35;
    }
    glPushMatrix();
    glTranslatef(meghX, 0, 0);
    cloud();
    glPopMatrix();


}
void Back(float x, float y, float z, float a,float b,float c, float r)
{
    glPushMatrix();//back
    glTranslatef(a,b,-c);
    glScalef(x,y,z);
    glRotatef(r,0,1,0);
    drawBox();
    glPopMatrix();
}
void cloud_area(float a, float b)//1st 2 row cloud
{
    glPushMatrix();
    glTranslatef(-10,a,-b);
    movecloud(10);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-10,a,-b);
    movecloud(-10);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(20,a,-b);
    movecloud(20);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-20,a,-b);
    movecloud(-20);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,a,-b);
    movecloud(0);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(15,a-5,-b);
    movecloud(15);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-15,a-5,-b);
    movecloud(-15);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(5,a-5,-b);
    movecloud(5);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-5,a-5,-b);
    movecloud(-5);
    glPopMatrix();
}

void petal()
{

    glPushMatrix();

    glRotatef(90,0,0,1);
    //glRotatef(-30,0,0,1);
    //glRotatef(60,0,1,0);
    glScalef(0.5,0.5,0.5);
    bottleBezier();
    glPopMatrix();

}
void flower()
{
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D,ID[12]);
    glPushMatrix();
    glTranslatef(0,-0.5,0);
    petal();
    glPopMatrix();
    for (int i=0; i<=360; i+=60)
    {
        glPushMatrix();
        //glScalef(0.1,1,1);

        glRotatef(i,0,1,0);
        glRotatef(60,0,0,1);
        //glRotatef(90,1,0,0);
        petal();
        glPopMatrix();
    }
    glDisable(GL_TEXTURE_2D);

}
void leaf()
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    //glRotatef(90,0,0,1);
    glBindTexture(GL_TEXTURE_2D,ID[2]);
    glBegin(GL_TRIANGLE_FAN);

    glVertex2f(0.0,0.0);
    glVertex2f(-2.0,2.0);
    glVertex2f(0.0,3.0);
    glVertex2f(2.0,3.0);
    glVertex2f(3.0,2.0);
    glVertex2f(3.50,.50);
    glVertex2f(3.0,-1.0);
    glVertex2f(2.0,-2.0);
    glVertex2f(0.0,-2.50);
    glVertex2f(-2.0,-2.0);
    glVertex2f(-3.0,-1.0);
    glEnd();
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}
void flowerwithleaf()
{
    glPushMatrix();
    flower();
    glPopMatrix();
    glPushMatrix();
    glRotatef(90,1,0,0);
    leaf();
    glPopMatrix();
}
void lake()
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[7]);
    //glTranslatef(0,0,Tzval);
    glScalef(3,0.25,2.5);
    drawBox();
    glPopMatrix();



    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[0]);
    glScalef(3.5,0.5,0.25);
    glTranslatef(0,0,20);
    drawBox();
    glPopMatrix();

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[0]);
    glScalef(3.5,0.5,0.25);
    glTranslatef(0,0,-20);
    drawBox();
    glPopMatrix();

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[0]);
    glScalef(0.25,0.5,2.25);
    glTranslatef(26,0,0);
    drawBox();
    glPopMatrix();

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[0]);
    glScalef(0.25,0.5,2.25);
    glTranslatef(-26,0,0);
    drawBox();
    glPopMatrix();


}
void rain()
{

    for(int i=1; i<=100; i++)
    {


        int x=rand(),y=rand();
        x%=640;
        y%=480;
        //if(x>=120&&x<=280&&y<=280)continue;
        glBegin(GL_LINES);
        glColor3b(1,1,1);
        glVertex2d(x,y);
        glVertex2d(x+5,y+5);
        glEnd();
    }
}
void reflect()//water reflection of monument
{
    glScalef(1,1,0.0001);
    glRotatef(180,0,1,0);
    //glRotatef(90,0,0,1);
    //glTranslatef(-100,-400,-500);
    //Drawflag();
    monument(180);
}
void dis()
{


    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,ID[0]);
    glScalef(15,0.25,20);
    drawBox(1,0,0);
    glPopMatrix();

    if(n1==0)glBindTexture(GL_TEXTURE_2D,ID[11]);
    else glBindTexture(GL_TEXTURE_2D,ID[13]);
    glPushMatrix();//back
    Back(15,35,0.001,0,0,-40,180);
    glPopMatrix();

    glPushMatrix();//front
    Back(15,35,0.001,0,0,40,0);
    glPopMatrix();

    glPushMatrix();//left
    Back(0.001,35,20,-30,0,0,0);
    glPopMatrix();

    glPushMatrix();//right
    Back(0.001,35,20,30,0,0,180);
    glPopMatrix();

    glPushMatrix();//top
    if(n1==0)glBindTexture(GL_TEXTURE_2D,ID[4]);
    else glBindTexture(GL_TEXTURE_2D,ID[13]);
    glTranslatef(0,70,0);
    glScalef(15,0.001,20);
    drawBox();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,0,13);
    glBindTexture(GL_TEXTURE_2D,ID[0]);
    glTranslatef(0,0.5,-30);
    glScalef(9,0.5,9);
    drawBox();
    glPopMatrix();
    if(f2==0)
    {
        //sun
        if(n1==0)glBindTexture(GL_TEXTURE_2D,ID[10]);
        else glBindTexture(GL_TEXTURE_2D,ID[12]);
        glPushMatrix();
        glScalef(1,2,1);
        glTranslatef(-20,28,-30);
        sphere(0.937, 0.556, 0.219);
        glPopMatrix();
        glDisable(GL_TEXTURE_2D);
    }

    glPushMatrix();
    glTranslatef(0,3,-4);
    glScalef(3,3,3);
    monument(0);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,0.5,20);
    glScalef(0.75,0.5,3);
    lake();
    glPopMatrix();

    glPushMatrix();
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glTranslatef(0,0.8,7);
    glRotatef(90,1,0,0);
    glScalef(0.9,0.9,0.75);
    reflect();
    glDisable(GL_BLEND);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,0.85,20);
    glScalef(0.15,0.15,0.15);
    flowerwithleaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-0.5,0.85,19);
    glScalef(0.15,0.15,0.15);
    glRotatef(90,1,0,0);
    glRotatef(180,0,1,0);
    leaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-2,0.85,15);
    glScalef(0.15,0.15,0.15);
    glRotatef(45,0,1,0);
    flowerwithleaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-1.75,0.85,14);
    glScalef(0.15,0.15,0.15);
    glRotatef(90,1,0,0);
    leaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(2.5,0.85,17);
    glScalef(0.15,0.15,0.15);
    glRotatef(135,0,1,0);
    flowerwithleaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(3,0.85,17.5);
    glScalef(0.15,0.15,0.15);
    glRotatef(90,1,0,0);
    leaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(2.5,0.85,16);
    glScalef(0.15,0.15,0.15);
    glRotatef(90,1,0,0);
    glRotatef(180,0,1,0);
    leaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-2.5,0.85,23);
    glScalef(0.15,0.15,0.15);
    glRotatef(135,0,1,0);
    flowerwithleaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-3,0.85,23.5);
    glScalef(0.15,0.15,0.15);
    glRotatef(90,1,0,0);
    leaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-2.5,0.85,22);
    glScalef(0.15,0.15,0.15);
    glRotatef(90,1,0,0);
    glRotatef(180,0,1,0);
    leaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(1.75,0.85,26);
    glScalef(0.15,0.15,0.15);
    glRotatef(135,0,1,0);
    flowerwithleaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(1.25,0.85,26.5);
    glScalef(0.15,0.15,0.15);
    glRotatef(90,1,0,0);
    leaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-3.25,0.85,30.5);
    glScalef(0.15,0.15,0.15);
    glRotatef(90,1,0,0);
    leaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-3.75,0.85,30.5);
    glScalef(0.15,0.15,0.15);
    glRotatef(135,0,1,0);
    flowerwithleaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(3.25,0.85,31.5);
    glScalef(0.15,0.15,0.15);
    glRotatef(90,1,0,0);
    leaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(3.75,0.85,31.75);
    glScalef(0.15,0.15,0.15);
    glRotatef(135,0,1,0);
    flowerwithleaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,0.85,31.5);
    glScalef(0.15,0.15,0.15);
    glRotatef(90,1,0,0);
    leaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.5,0.85,31.75);
    glScalef(0.15,0.15,0.15);
    glRotatef(45,0,1,0);
    flowerwithleaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(1.5,0.85,13.5);
    glScalef(0.15,0.15,0.15);
    glRotatef(135,0,1,0);
    flowerwithleaf();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(1,0.85,13.0);
    glScalef(0.15,0.15,0.15);
    glRotatef(90,1,0,0);
    leaf();
    glPopMatrix();


    glPushMatrix();//left triangle grass 3 middle
    glTranslatef(13,2.25,22);
    glRotatef(180,0,1,0);
    tri_base_grass();
    glPopMatrix();

    glPushMatrix();//right triangle grass 3 middle
    glTranslatef(-13,2.25,22);
    //glRotatef(180,0,1,0);
    tri_base_grass();
    glPopMatrix();

    glPushMatrix();//left square grass 3 middle
    glTranslatef(-20,0.25,22);
    glScalef(0.5,1,2);
    grass();
    glPopMatrix();

    glPushMatrix();//right square grass 3 middle
    glTranslatef(20,0.25,22);
    glScalef(0.5,1,2);
    grass();
    glPopMatrix();

    glPushMatrix();//left square grass 3 top
    glTranslatef(-10,0.25,10);
    glScalef(0.5,1,0.5);
    grass();
    glPopMatrix();

    glPushMatrix();//right square grass 3 top
    glTranslatef(10,0.25,10);
    glScalef(0.5,1,0.5);
    grass();
    glPopMatrix();

    glPushMatrix();//left square grass 3 bottom
    glTranslatef(-10,0.25,32);
    glScalef(0.5,1,0.5);
    grass();
    glPopMatrix();

    glPushMatrix();//right square grass 3 bottom
    glTranslatef(10,0.25,32);
    glScalef(0.5,1,0.5);
    grass();
    glPopMatrix();

    glPushMatrix();//left side tree
    glTranslatef(-28,0.5,0);
    glRotatef(90,0,1,0);
    trees(20);
    glPopMatrix();

    glPushMatrix();//right side tree
    glTranslatef(28,0.5,0);
    glRotatef(90,0,1,0);
    trees(20);
    glPopMatrix();

    glPushMatrix();//right front side tree
    glTranslatef(17,0.5,39);
    trees(5);
    glPopMatrix();

    glPushMatrix();//left front side tree
    glTranslatef(-17,0.5,39);
    trees(5);
    glPopMatrix();

    glPushMatrix();//backside tree
    glTranslatef(0,0.5,-39);
    trees(14);
    glPopMatrix();




}
void final_dis()
{
    glPushMatrix();
    dis();
    glPopMatrix();

    glPushMatrix();
    cloud_area(60,35);
    glPopMatrix();

    if(f2==1)
    {
        glPushMatrix();
        glScalef(0.13,0.2,1);
        glTranslatef(-325,-20,0);
        for(float i=-2; i<2.85; i+=0.05)
        {
            glTranslatef(0,0,i);
            rain();
        }

        glPopMatrix();
    }

}

void setPerspectiveProjection();
void cameraUpdateForwardSpeed();
void cameraUpdateLeftRightSpeed();

void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    setPerspectiveProjection();
    cameraUpdateForwardSpeed();
    cameraUpdateLeftRightSpeed();

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(eyeX,eyeY,eyeZ, refX,refY,refZ, 0,1,0);


    glRotatef( alpha,axis_x, axis_y, 0.0 );
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glPushMatrix();
    //lake();
    //flowerwithleaf();
    //flower();
    // dis();
    final_dis();
//bottleBezier();
    glPopMatrix();

    glPushMatrix();
    light();
    light1();
    glPopMatrix();


    glFlush();
    glutSwapBuffers();

}

// Function declarations (since they are implemented at bottom)
void cameraMoveForward();
void cameraMoveBackward();
void cameraMoveRight();
void cameraMoveLeft();
void rotateCameraY(double rotation);
void cameraMoveUpDown(double movement);
void changeFocusOfView(double angle);
void resetCamera();

void myKeyboardFunc( unsigned char key, int x, int y )
{
    switch ( key )
    {
    case 'T':
    case 't':
        bRotate = !bRotate;
        uRotate = false;
        axis_x=0.0;
        axis_y=1.0;
        break;

    case 'w':
    case 'W':
        cameraMoveForward();
        break;
    case 's':
    case 'S':
        cameraMoveBackward();
        break;
    case 'd':
    case 'D':
        cameraMoveRight();
        break;
    case 'a':
    case 'A':
        cameraMoveLeft();
        break;
    case 'q':
    case 'Q':
        rotateCameraY(1.5); // Rotate left
        break;
    case 'e':
    case 'E':
        rotateCameraY(-1.5); // Rotate right
        break;
    case 'z':
    case 'Z':
        cameraMoveUpDown(0.5);  // Move up
        break;
    case 'x':
    case 'X':
        cameraMoveUpDown(-0.5); // Move down
        break;
    case '+':
    case '=':
        changeFocusOfView(-1.0); // Zoom in
        break;
    case '-':
        changeFocusOfView(1.0); // Zoom out
        break;
    case 'r':
    case 'R':
        resetCamera();  // Reset camera
        break;
    case '1': //to turn on and off light one moon and sun light
        if(s1 == false)
        {
            a0=true;
            d0=true;
            s0=true;
            s1 = true;
            glEnable( GL_LIGHT0);
            break;
        }
        else if(s1 == true)
        {
            a0=true;
            d0=true;
            s0=true;
            s1 = false;
            glDisable( GL_LIGHT0);
            break;
        }

    case '2': //to turn on and off light 2 monument light
        if(s2 == false)
        {
            a0=true;
            d0=true;
            s0=true;
            s2 = true;
            glEnable( GL_LIGHT1);
            break;
        }
        else if(s2 == true)
        {
            a0=true;
            d0=true;
            s0=true;
            s2 = false;
            glDisable( GL_LIGHT1);
            break;
        }

    case '4'://ambient
        a0=true;
        d0=false;
        s0=false;
        break;
    case '5'://diffuse
        a0=false;
        d0=true;
        s0=false;
        break;
    case '6'://specular
        a0=false;
        d0=false;
        s0=true;
        break;
    case '7'://cloud on 0ff
        if(clo1==1)
        {
            clo=1;
            clo1=0;
        }
        else
        {
            clo=0;
            clo1=1;
        }
        break;
    case '8'://rain on off
        if(f3==1)
        {
            f2=1;
            f3=0;
        }
        else
        {
            f2=0;
            f3=1;

        }
        break;
    case '9'://night mode on off
        if(n2==1)
        {
            n1=1;
            n2=0;
        }
        else
        {
            n1=0;
            n2=1;

        }
        break;
    case 27:    // Escape key
        exit(1);
    }
    glutPostRedisplay();
}

void animate()
{
    if (bRotate == true)
    {
        theta += 0.2;
        if(theta > 360.0)
            theta -= 360.0*floor(theta/360.0);
    }

    if (uRotate == true)
    {
        alpha += 0.2;
        if(alpha > 360.0)
            alpha -= 360.0*floor(alpha/360.0);
    }
    if(AniFlag == 1)
    {
        if(ya>-50 && yFlag == 1)
            ya = ya - 0.2;

        if(ya<=-50 && yFlag == 1)
            yFlag = 0;

        if(ya<50 && yFlag == 0)
            ya = ya + 0.2;

        if(ya>=50 && yFlag == 0)
            yFlag = 1;


        if(xa>-10 && xFlag == 1)
            xa = xa - 0.2;

        if(xa<=-10 && xFlag == 1)
            xFlag = 0;

        if(xa<10 && xFlag == 0)
            xa = xa + 0.2;

        if(xa>=10 && xFlag == 0)
            xFlag = 1;
    }
    glutPostRedisplay();

}

void LoadTexture(const char*filename)
{

    glGenTextures(1, &id);
    glBindTexture(GL_TEXTURE_2D, id);
    glPixelStorei(GL_UNPACK_ALIGNMENT, id);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    BmpLoader bl(filename);
    gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGB, bl.iWidth, bl.iHeight, GL_RGB, GL_UNSIGNED_BYTE, bl.textureData );
}


void texture()
{
    LoadTexture("C:/Users/Asus/OneDrive/Desktop/lab/graphics cse 4208/1607004_monument/brick.bmp");
    ID.push_back(id);
    LoadTexture("C:/Users/Asus/OneDrive/Desktop/lab/graphics cse 4208/1607004_monument/bas.bmp");
    ID.push_back(id);
    LoadTexture("C:/Users/Asus/OneDrive/Desktop/lab/graphics cse 4208/1607004_monument/leaf.bmp");
    ID.push_back(id);
    LoadTexture("C:/Users/Asus/OneDrive/Desktop/lab/graphics cse 4208/1607004_monument/bark.bmp");
    ID.push_back(id);
    LoadTexture("C:/Users/Asus/OneDrive/Desktop/lab/graphics cse 4208/1607004_monument/sky1.bmp");
    ID.push_back(id);
    LoadTexture("C:/Users/Asus/OneDrive/Desktop/lab/graphics cse 4208/1607004_monument/cloud.bmp");
    ID.push_back(id);
    LoadTexture("C:/Users/Asus/OneDrive/Desktop/lab/graphics cse 4208/1607004_monument/grass.bmp");
    ID.push_back(id);
    LoadTexture("C:/Users/Asus/OneDrive/Desktop/lab/graphics cse 4208/1607004_monument/lake.bmp");
    ID.push_back(id);
    LoadTexture("C:/Users/Asus/OneDrive/Desktop/lab/graphics cse 4208/1607004_monument/brick1.bmp");
    ID.push_back(id);
    LoadTexture("C:/Users/Asus/OneDrive/Desktop/lab/graphics cse 4208/1607004_monument/flag.bmp");
    ID.push_back(id);
    LoadTexture("C:/Users/Asus/OneDrive/Desktop/lab/graphics cse 4208/1607004_monument/sun.bmp");
    ID.push_back(id);
    LoadTexture("C:/Users/Asus/OneDrive/Desktop/lab/graphics cse 4208/1607004_monument/background.bmp");
    ID.push_back(id);
    LoadTexture("C:/Users/Asus/OneDrive/Desktop/lab/graphics cse 4208/1607004_monument/white.bmp");
    ID.push_back(id);
    LoadTexture("C:/Users/Asus/OneDrive/Desktop/lab/graphics cse 4208/1607004_monument/night.bmp");
    ID.push_back(id);



}
// Function declarations (since they are implemented at bottom)
void myMotionFunc(int x, int y);
void myMouseFunc(int button, int state, int x, int y);

int main (int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(width,height);
    glutInitWindowPosition(10,10);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutCreateWindow("MONUMENT-1607004");

    printf("\t********** Activities **********\n");
    printf( "\tFOR Camera Movement , Hold + Drag On The Mouse \n");
    printf(" \tFOR Forward Movement , PRESS W/w \n ");
    printf(" \tFOR Backward Movement , PRESS S/s \n ");
    printf(" \tFOR Right Movement , PRESS D/d \n ");
    printf(" \tFOR Left Movement , PRESS A/a \n ");
    printf(" \tFOR Rotating Left , PRESS Q/q \n ");
    printf(" \tFOR Rotating Right , PRESS E/e \n ");
    printf(" \tFOR Up Movement , PRESS Z/z \n ");
    printf(" \tFOR Down Movement , PRESS X/x \n ");
    printf(" \tFOR Rotating On Off Along Y Axis , PRESS T/t \n ");
    printf("\tFOR ZOOM IN, PRESS + \n");
    printf("\tFOR ZOOM OUT, PRESS - \n");
    printf("\tTo turn on and off light 1(Sunlight Normal DayLight & Moonlight spotlight) ,press 1 \n");
    printf("\tTo turn on and off light 2 (Monument light) ,press 2\n");
    printf("\tTo turn on and off ambient property ,press 4\n");
    printf("\tTo turn on and off diffuse property ,press 5\n");
    printf("\tTo turn on and off specular property ,press 6\n");
    printf("\tFOR Cloud Movement On and Off, PRESS 7 \n");
    printf("\tFOR Rain Effect On and Off, PRESS 8 \n");
    printf("\tFOR Night Effect On and Off, PRESS 9 \n");
    printf("\tTO Reset, PRESS R \n");



    glutDisplayFunc(display);
    glutKeyboardFunc(myKeyboardFunc);
    glutMouseFunc(myMouseFunc);
    glutMotionFunc(myMotionFunc);
    glutReshapeFunc(resizeView);
    glutIdleFunc(animate);
    texture();

    //glClearColor(0,0,0,1);


    glEnable(GL_BLEND);
    glShadeModel( GL_SMOOTH );
    glEnable( GL_DEPTH_TEST );
    glEnable(GL_NORMALIZE);
    glEnable(GL_LIGHTING);
    light();
    light1();
//    light2();



    glutMainLoop();

    return 0;
}

// We need to store the mouse coordinate to find the relative mouse movement (new position - last position = relative position)
// So that we can use that value to rotate our camera
int mouseLastX = 0;
int mouseLastY = 0;

// Current camera rotation value along X and Y (Z is not needed since it rolls the camera which is not needed here)
double cameraYRotation = 0.0;       // also called yaw
double cameraXRotation = 0.0;       // also called pitch

// These are temporary variables to store calculate new rotation value (new rotation = old rotation + relative rotation)
double newCameraYRotation = 0.0;
double newCameraXRotation = 0.0;

// Fixed camera rotation speed done by mouse,
double cameraRotationSpeed = 0.1;

// To store camera forward/backward, left/right speed for internal use.
double cameraForwardSpeed = 0.0;
double cameraLeftRightSpeed = 0.0;

// Some other internal use variables
// Forward vector = eye vector + 1.0 distance forward
double forwardX = eyeX;
double forwardY = eyeY;
double forwardZ = eyeZ + 1.0;

// Right vector = eye vector + 1.0 distance to the right side
double rightX = eyeX + 1.0;
double rightY = eyeY;
double rightZ = eyeZ;

// Field of view angle (you can change it using keyboard + and -, this works as a zoom for camera)
double fovAngle = 70.0;

// Function : Update the camera direction based on the rotation (yaw, pitch) given
void updateCameraLookAt(double xRotation, double yRotation)
{
    double pitch = xRotation * PI / 180.0;
    double yaw = yRotation * PI / 180.0;

    if (pitch < -1.5) pitch = -1.5;
    if (pitch > 1.5) pitch = 1.5;

    // Find the forward vector
    forwardX = -sin(yaw) * cos(pitch);
    forwardY = -sin(pitch);
    forwardZ = -cos(yaw) * cos(pitch);

    // Find the right vector
    rightX = -cos(yaw);
    rightY = 0.0;
    rightZ = sin(yaw);

    // Find the up vector using cross product of forward and right vector
    double upX = forwardY * rightZ - forwardZ * rightY;
    double upY = forwardX * rightZ - forwardZ * rightX;
    double upZ = forwardX * rightY - forwardY * rightX;

    // Find magnitude of each vectors
    double forwardLength = sqrt( forwardX * forwardX + forwardY * forwardY + forwardZ * forwardZ );
    double rightLength = sqrt( rightX * rightX + rightY * rightY + rightZ * rightZ );
    double upLength = sqrt( upX * upX + upY * upY + upZ * upZ );

    // Normalize forward vector
    forwardX = forwardX / forwardLength;
    forwardY = forwardY / forwardLength;
    forwardZ = forwardZ / forwardLength;

    // Normalize right vector
    rightX = rightX / rightLength;
    rightY = rightY / rightLength;
    rightZ = rightZ / rightLength;

    // Normalize up vector
    upX = upX / upLength;
    upY = upY / upLength;
    upZ = upZ / upLength;

    // Set camera direction
    refX = eyeX + forwardX;
    refY = eyeY + forwardY;
    refZ = eyeZ + forwardZ;

    // Store the rotation value
    cameraXRotation = xRotation;
    cameraYRotation = yRotation;

    // The purpose of this function is too take angles and convert them to directions
}

// This is a glut build in function to give you mouse position when you tap hold + drag on the mouse
void myMotionFunc(int x, int y)
{
    // Find the relative movement
    int relX = x - mouseLastX;
    int relY = y - mouseLastY;

    // Store the value
    mouseLastX = x;
    mouseLastY = y;

    // Calculate horizontal and vertical rotation for camera
    double relHorizontal = relX * cameraRotationSpeed;
    newCameraYRotation = cameraYRotation + relHorizontal;

    double relVertical = relY * cameraRotationSpeed;
    newCameraXRotation = cameraXRotation - relVertical;

    // Update the direction by these rotations
    updateCameraLookAt(newCameraXRotation, newCameraYRotation);
}

// Glut build in function, gives position when you tap on the mouse. State == 0 means when you just clicked (MouseDown event)
void myMouseFunc(int button, int state, int x, int y)
{
    if (state == 0)
    {
        mouseLastX = x;
        mouseLastY = y;
    }
}

// Update camera perspective projection
void setPerspectiveProjection()
{
    double fov = fovAngle;
    double aspect = glutGet(GLUT_SCREEN_WIDTH) / glutGet(GLUT_SCREEN_HEIGHT);
    double near_dist = 0.1;
    double far_dist = 1000.0;

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(fov, aspect, near_dist, far_dist);
    glMatrixMode(GL_MODELVIEW);
}


void cameraMoveForward()
{
    cameraForwardSpeed = cameraForwardSpeed + 0.1;
    if (cameraForwardSpeed > 1.0) cameraForwardSpeed = 1.0;
}

void cameraMoveBackward()
{
    cameraForwardSpeed = cameraForwardSpeed - 0.1;
    if (cameraForwardSpeed < -1.0) cameraForwardSpeed = -1.0;
}

void cameraMoveRight()
{
    cameraLeftRightSpeed = cameraLeftRightSpeed - 0.1;
    if (cameraLeftRightSpeed < -1.0) cameraLeftRightSpeed = -1.0;
}

void cameraMoveLeft()
{
    cameraLeftRightSpeed = cameraLeftRightSpeed + 0.1;
    if (cameraLeftRightSpeed > 1.0) cameraLeftRightSpeed = 1.0;
}

// Move the camera forward/backward based on the current speed
void cameraUpdateForwardSpeed()
{
    double directionX;
    double directionY;
    double directionZ;

    directionX = refX - eyeX;
    directionY = refY - eyeY;
    directionZ = refZ - eyeZ;

    double mag = sqrt( directionX * directionX + directionY * directionY + directionZ * directionZ);
    directionX = directionX / mag;
    directionY = directionY / mag;
    directionZ = directionZ / mag;

    eyeX = eyeX + directionX * cameraForwardSpeed;
    refX = refX + directionX * cameraForwardSpeed;

    eyeY = eyeY + directionY * cameraForwardSpeed;
    refY = refY + directionY * cameraForwardSpeed;

    eyeZ = eyeZ + directionZ * cameraForwardSpeed;
    refZ = refZ + directionZ * cameraForwardSpeed;


    cameraForwardSpeed = cameraForwardSpeed * 0.9;
    if (cameraForwardSpeed > -0.02 && cameraForwardSpeed < 0.02) cameraForwardSpeed = 0.0;

}

// Move the camera left/right based on the current speed (this is little difficult that moving forward/backward)

void cameraUpdateLeftRightSpeed()
{
    double directionX;
    double directionY;
    double directionZ;

    double pitch = cameraXRotation * PI / 180.0;
    double yaw = cameraYRotation * PI / 180.0;

    double rX = -cos(yaw);
    double rY = 0.0;
    double rZ = sin(yaw);
    double rLength = sqrt( rX * rX + rY * rY + rZ * rZ );

    rX = rX / rLength;
    rY = rY / rLength;
    rZ = rZ / rLength;

    directionX = rX;
    directionY = rY;
    directionZ = rZ;

    eyeX = eyeX + directionX * cameraLeftRightSpeed;
    refX = refX + directionX * cameraLeftRightSpeed;

    eyeY = eyeY + directionY * cameraLeftRightSpeed;
    refY = refY + directionY * cameraLeftRightSpeed;

    eyeZ = eyeZ + directionZ * cameraLeftRightSpeed;
    refZ = refZ + directionZ * cameraLeftRightSpeed;


    cameraLeftRightSpeed = cameraLeftRightSpeed * 0.9;
    if (cameraLeftRightSpeed > -0.02 && cameraLeftRightSpeed < 0.02) cameraLeftRightSpeed = 0.0;
}

void rotateCameraY(double rotation)
{
    updateCameraLookAt(cameraXRotation, cameraYRotation + rotation);
}

void cameraMoveUpDown(double movement)
{
    eyeY = eyeY + movement;
    refY = refY + movement;
}

// Basically does the zoom in/out
void changeFocusOfView(double angle)
{
    fovAngle = fovAngle + angle;
    if (fovAngle < 40.0) fovAngle = 40.0;
    if (fovAngle > 90.0) fovAngle = 90.0;
}

void resetCamera()
{
    eyeX = 0.0;
    eyeY = 2.5;
    eyeZ = 20.0;
    refX = 0.0;
    refY = 2.5;
    refZ = 19.0;
    cameraYRotation = 0.0;
    newCameraYRotation = 0.0;
    cameraRotationSpeed = 0.1;
    cameraXRotation = 0.0;
    newCameraXRotation = 0.0;
    cameraForwardSpeed = 0.0;
    cameraLeftRightSpeed = 0.0;
    forwardX = eyeX;
    forwardY = eyeY;
    forwardZ = eyeZ + 1.0;
    rightX = eyeX + 1.0;
    rightY = eyeY;
    rightZ = eyeZ;
    fovAngle = 70.0;
}





